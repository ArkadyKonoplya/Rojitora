<?php

use Illuminate\Database\Seeder;
use App\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->delete();
 
        $users = array(
            [
                'id'              => 1,
                'member_id'       => '1732',
                'company_name1'   => 'テラテクニカル株式会社',
                'company_name2'   => 'てらてくにかるかぶしきかいしゃ',
                'postal_code'     => '379-2213',
                'address_fir'     => '群馬県',
                'address_sec'     => '高崎市綿貫町',
                'address_thi'     => '1475-1高軽103',
                'information_fir' => '影山',
                'information_sec' => 'かげやま',
                'phone_number'   => '080-3547-3048',
                'fax_number'      => '03-63693550',
                'email'           => 'kageyama@tera-technical.com',
                'password'        => bcrypt('55555'),
                'referee'         => '㈱ロジテル',
                'where_learn'     => 'その他'
            ],
            [
                'id'              => 2,
                'member_id'       => '4094',
                'company_name1'   => 'テラテクニカル株式会社',
                'company_name2'   => 'てらてくにかるかぶしきかいしゃ',
                'postal_code'     => '379-1334',
                'address_fir'     => '群馬県',
                'address_sec'     => '高崎市綿貫町',
                'address_thi'     => '1425-2高軽105',
                'information_fir' => '影山',
                'information_sec' => 'かげやま',
                'phone_number'   => '080-3547-6049',
                'fax_number'      => '03-63693549',
                'email'           => 'admin@test.com',
                'password'        => bcrypt('123'),
                'referee'         => '㈱ロジテル',
                'where_learn'     => 'その他'
            ]
        );
 
        // Uncomment the below to run the seeder
        DB::table('users')->insert($users);
    }
}
