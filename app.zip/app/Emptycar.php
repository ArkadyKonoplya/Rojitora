<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Emptycar extends Model
{
	protected $table = 'emptycars';  

	protected $guarded = [];
}
