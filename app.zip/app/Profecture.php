<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Profecture extends Model
{
	protected $table = 'profectures';
    //
    protected $guarded = [];
}
