<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Luggage extends Model
{
	protected $table = 'luggage';
    //
    protected $guarded = [];
}
