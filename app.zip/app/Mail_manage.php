<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mail_manage extends Model
{
	protected $table = 'mail_manages';
	protected $guarded = [];
    //
}
