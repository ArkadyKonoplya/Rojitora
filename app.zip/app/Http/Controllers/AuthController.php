<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;


class AuthController extends Controller
{

    public function register(Request $request)
    {

        $v = Validator::make($request->all(), [
            'company_name1' => 'required',
            'postal_code' => 'required',
            'address_fir' => 'required',
            'address_sec' => 'required',
            'information_fir' => 'required',
            'phone_number' => 'required',
            'fax_number' => 'required',
            'email' => 'required|email|unique:users',
            'password'  => 'required|min:3|confirmed',
            'referee' => 'required',
            'where_learn' => 'required'
        ]);
        if ($v->fails())
        {
            return response()->json([
                'error' => 'registration_validation_error',
                'errors' => $v->errors()
            ], 422);
        }
        $digits = 4;
        do {
            $digits_number = rand(pow(10, $digits-1), pow(10, $digits)-1);
            $member_cnt = DB::table('users')->select('member_id')->where('member_id', '=',$digits_number)->get()->count();
        }while ($member_cnt <> 0);
        if($fb = fopen("debug.txt","w")){
            fwrite($fb,$member_cnt . $digits_number);
            fclose($fb);
        }           

        $user = new User;
        $user->member_id = $digits_number;
        $user->company_name1 = $request->company_name1;
        $user->company_name2 = $request->company_name2;
        $user->postal_code = $request->postal_code;
        $user->address_fir = $request->address_fir;
        $user->address_sec = $request->address_sec;
        $user->address_thi = $request->address_thi;
        $user->information_fir = $request->information_fir;
        $user->information_sec = $request->information_sec;
        $user->phone_number = $request->phone_number;
        $user->fax_number = $request->fax_number;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);
        $user->referee = $request->preferee;
        $user->where_learn = $request->where_learn;

        $user->save();
     
        return response()->json(['status' => 'success'], 200);
    }

    public function login(Request $request)
    {
        $digits = 4;
        $digits_number = rand(pow(10, $digits-1), pow(10, $digits)-1);
        // echo($digit);
        // if ($fb = fopen("debug.txt","w")){
        //     fwrite($fb, "string");
        //     fclose($fb);
        // }
        $credentials = $request->only('email', 'password');

        if($fb = fopen("debug.txt","w")){
            fwrite($fb,$digits_number);
            fclose($fb);
        }

        if ($token = $this->guard()->attempt($credentials)) {
            return response()->json(['status' => 'success'], 200)->header('Authorization', $token);
        }

        return response()->json(['error' => 'login_error'], 401);
    }

    public function logout()
    {
        $this->guard()->logout();

        return response()->json([
            'status' => 'success',
            'msg' => 'Logged out Successfully.'
        ], 200);
    }

    public function user(Request $request)
    {
        $user = User::find(Auth::user()->id);

        return response()->json([
            'status' => 'success',
            'data' => $user
        ]);
    }

    public function refresh()
    {
        if ($token = $this->guard()->refresh()) {
            return response()
                ->json(['status' => 'successs'], 200)
                ->header('Authorization', $token);
        }

        return response()->json(['error' => 'refresh_token_error'], 401);
    }

    private function guard()
    {
        return Auth::guard();
    }
}

