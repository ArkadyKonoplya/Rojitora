<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mail_manage;

class Mail_managesController extends Controller
{
    public function __construct()
    {
       
        $this->middleware('auth:api');
    }	
    public function index()
    {
    	$mail_manage = Mail_manage::all();
    	return response()->json($mail_manage);
    }
    public function create()
    {

    }
    public function store(Request $request)
    {
    	$mail_manage = new Mail_manage([
    		'first_name' => $request->get('first_name'),
    		'last_name' => $request->get('last_name'),
    		'company_name1' => $request->get('company_name1'),
    		'company_name2' => $request->get('company_name2'),
    		'address_1' => $request->get('address_1'),
    		'address_2' => $request->get('address_2'),
    		'address_3' => $request->get('address_3'),
    		'email' => $request->get('email'),
    		'phone_number' => $request->get('phone_number'),
    		'question_content' => $request->get('question_content'),
    	]);
    	$mail_manage->save();
    	return response()->json('Successfully added');
    }
    public function show($id)
    {

    }
    public function edit($id)
    {
    	$mail_manage = Mail_manage::find($id);
    	return response()->json($mail_manage);
    }
    public function update(Request $request,$id)
    {
    	$mail_manage = Mail_manage::find($id);
    	$mail_manage->first_name = $request->get('first_name');
    	$mail_manage->last_name = $request->get('last_name');
    	$mail_manage->company_name1 = $request->get('company_name1');
    	$mail_manage->company_name2 = $request->get('company_name2');
    	$mail_manage->address_1 = $request->get('address_1');
    	$mail_manage->address_2 = $request->get('address_2');
    	$mail_manage->address_3 = $request->get('address_3');
    	$mail_manage->email = $request->get('email');
    	$mail_manage->phone_number = $request->get('phone_number');
    	$mail_manage->question_content = $request->get('question_content');
    	$mail_manage->save();
    	return response()->json('Successfully Updated');
    }
    public function destroy($id)
    {
    	$mail_manage = Mail_manage::find($id);
    	$mail_manage->delete();
    	return response()->json('Successfully Deleted');
    }

}
